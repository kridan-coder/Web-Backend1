﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Backend1.Models
{
    public class DateTimeViewModel
    {
        public DateTime Current { get; set; }
    }
}
